<?php
require_once 'core/controllerClass.php';
require_once 'core/viewClass.php';
require_once 'core/modelClass.php';
require_once 'core/routerClass.php';
require_once 'core/configClass.php';

Router::run();