<br>
<footer>
    <div id="footer" align="center">
        <p>
            <small>Тестовая версия <font color="red"><strong>v.test</strong></font> &copy; 2015-2016</small>
        </p>
    </div>
</footer>
