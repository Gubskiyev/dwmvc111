<?php
class ModelForum extends Model {

    public function getAllForums() {
        return $this->select("SELECT * FROM `section`");
    }

    public function getThreadsBySection($section) {
        $sql = "SELECT * FROM `threads` WHERE `fid` = '$section' ORDER BY `id` DESC";
        return $this->select($sql);
    }

    public function getThreadByID($fid,$tid) {
        $sql = "SELECT * FROM `threads` WHERE `id` = '$tid' OR `mid` = '$tid'";
		return $this->select($sql);
    }

    public function addNewThread($fid,$title,$text,$user,$user_id,$date) {
		$sql = "INSERT INTO `threads` (`id`,`mid`,`fid`,`type`,`title`,`text`,`user`,`user_id`,`date`) VALUES ('NULL','0','$fid','topic','$title','$text','$user','$user_id','$date')";
        $this->query($sql);
    }

    public function addNewMessage($mid,$text,$user,$user_id,$date) {
        $sql = "INSERT INTO `threads` (`id`,`mid`,`fid`,`type`,`title`,`text`,`user`,`user_id`,`date`) VALUES ('NULL','$mid','0','topic','','$text','$user','$user_id','$date')";
		$this->query($sql);
    }

	public function getForumByID($id) {
        return $this->select("SELECT * FROM `section` WHERE `id` = '$id'");
    }
	
	//

    public function getUserData($login) {
        $sql = "SELECT `id`,`login` FROM `users` WHERE `login` = '$login'";
        return $this->select($sql);
    }


    public function getCountMessages($id) {
        $data = $this->select("SELECT * FROM `threads` WHERE `mid` = '".$id."'");
        $count = count($data);
        $count++;
        return $count;
    }

    public function getCountThreads($id) {
        $data = $this->select("SELECT * FROM `threads` WHERE `fid` = '".$id."'");
        $count = count($data);
        return $count;
    }
}