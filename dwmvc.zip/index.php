<?php
date_default_timezone_set('Asia/Yakutsk');
require_once 'app/start.php';